const mysql = require("mysql");
const jwt =require("jsonwebtoken")
const bcrypt=require("bcryptjs")
exports.signup =(req,res)=>{
    console.log("formdata:",req.body);
    const { signupFirstName, signupLastName, signupSex, signupDOB, signupAddress, signupEmail, signupPassword,confirmPassword } = req.body;
    console.log(signupFirstName, signupLastName, signupSex, signupDOB, signupAddress, signupEmail, signupPassword,confirmPassword);

    const db= mysql.createConnection({
        host:process.env.DATABASE_HOST,
        user:process.env.DATABASE_USER,
        password:process.env.DATABASE_PASSWORD,
        database:process.env.DATABASE
    });
    db.query('SELECT email FROM users WHERE email=?', [signupEmail], async(error,results)=>{
        if(error){
            console.log(error);
        }
        if(results.length>0){
            return res.render("index",{
                message:"Email is already registered"
            });

        }else if(signupPassword!==confirmPassword){
            return res.render("index",{
                message:"Passwords do not match"
            });
        }
        else{
            return res.status(200).send("Registered Successfully");
        }
        
    });
    
}