// app.js

document.getElementById('signupForm').addEventListener('submit', function (event) {
    event.preventDefault();
  
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
  
    fetch('/signup', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, password }),
    })
    .then(response => {
      if (response.ok) {
        alert('User registered successfully. Check your email for verification.');
      } else {
        alert('Error registering user. Please try again.');
      }
    })
    .catch(error => {
      console.error('Error:', error);
      alert('An unexpected error occurred. Please try again later.');
    });
  });
  
  document.getElementById('loginForm').addEventListener('submit', function (event) {
    event.preventDefault();
  
    const loginEmail = document.getElementById('loginEmail').value;
    const loginPassword = document.getElementById('loginPassword').value;
  
    fetch('/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email: loginEmail, password: loginPassword }),
    })
    .then(response => {
      if (response.ok) {
        return response.json();
      } else {
        alert('Invalid credentials. Please try again.');
      }
    })
    .then(data => {
      if (data && data.twoFactorCode) {
        document.getElementById('twoFactorForm').style.display = 'block';
  
        document.getElementById('twoFactorForm').addEventListener('submit', function (event) {
          event.preventDefault();
  
          const twoFactorCode = document.getElementById('twoFactorCode').value;
  
          fetch('/verify-2fa', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email: loginEmail, twoFactorCode }),
          })
          .then(response => {
            if (response.ok) {
              return response.json();
            } else {
              alert('Invalid 2FA code. Please try again.');
            }
          })
          .then(data => {
            if (data && data.message) {
              alert(data.message);
              if (data.visitTime) {
                alert(`Last login: ${data.visitTime}`);
              }
            }
          })
          .catch(error => {
            console.error('Error:', error);
            alert('An unexpected error occurred. Please try again later.');
          });
        });
      }
    })
    .catch(error => {
      console.error('Error:', error);
      alert('An unexpected error occurred. Please try again later.');
    });
  });
  
  function getUserLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
  
          fetch('/get-location', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ latitude, longitude }),
          })
          .then(response => {
            if (response.ok) {
              return response.json();
            } else {
              alert('Error getting user location. Please try again.');
            }
          })
          .then(data => {
            if (data && data.latitude && data.longitude) {
              const locationContainer = document.getElementById('locationContainer');
              locationContainer.innerHTML = `Your Location: ${data.latitude}, ${data.longitude}`;
  
              getWeather(data.latitude, data.longitude);
            }
          })
          .catch(error => {
            console.error('Error:', error);
            alert('An unexpected error occurred. Please try again later.');
          });
        },
        (error) => {
          console.error('Error getting location:', error);
          alert('Error getting location. Please allow location access and try again.');
        }
      );
    } else {
      alert('Geolocation is not supported by your browser.');
    }
  }
  
  function getWeather(latitude, longitude) {
    fetch('/get-weather', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ latitude, longitude }),
    })
    .then(response => {
      if (response.ok) {
        return response.json();
      } else {
        alert('Error getting weather information. Please try again.');
      }
    })
    .then(data => {
      if (data && data.weather && data.temperature) {
        const weatherContainer = document.getElementById('weatherContainer');
        weatherContainer.innerHTML = `Weather: ${data.weather}, Temperature: ${data.temperature} °C`;
      }
    })
    .catch(error => {
      console.error('Error:', error);
      alert('An unexpected error occurred. Please try again later.');
    });
  }
  
  getUserLocation();
  