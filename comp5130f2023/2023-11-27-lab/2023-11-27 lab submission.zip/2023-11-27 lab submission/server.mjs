// server.mjs

// Import necessary modules
import express from 'express';
import bodyParser from 'body-parser';
import { fileURLToPath } from 'url'; // Node.js url module
import path from 'path';
import fetch from 'node-fetch';
import nodemailer from 'nodemailer';

// Get the directory name using import.meta.url
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Create an Express application
const app = express();
const port = 3000;

// Middleware for parsing JSON and URL-encoded data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Map to store user data (replace this with a database in a real application)
const users = new Map();

// Nodemailer configuration for sending verification emails
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'your-email@gmail.com', // Replace with your Gmail email
    pass: 'your-email-password', // Replace with your Gmail password
  },
});

// Serve static files from the 'public' folder
app.use(express.static(path.join(__dirname, 'public')));

// Define a route for the root URL ("/") to serve the index.html file
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Route for user signup
app.post('/signup', (req, res) => {
  const { email, password } = req.body;

  // Validate email format
  const emailRegex = /^[a-zA-Z]+_[a-zA-Z]+@student.uml.edu$/;
  if (!emailRegex.test(email)) {
    return res.status(400).send('Invalid email format. Use firstname_lastname@student.uml.edu');
  }

  // Validate password format
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  if (!passwordRegex.test(password)) {
    return res.status(400).send('Invalid password format. Minimum 8 characters, 1 uppercase, 1 lowercase, 1 special, 1 numeric');
  }

  // Check if the user already exists
  if (users.has(email)) {
    return res.status(400).send('User already exists');
  }

  // Store user data (replace with database logic in a real application)
  users.set(email, { password });

  // Send verification email
  const mailOptions = {
    from: 'your-email@gmail.com', // Replace with your Gmail email
    to: email,
    subject: 'Email Verification',
    text: 'Please click on the following link to verify your email: http://your-verification-link',
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error(error);
      return res.status(500).send('Internal Server Error');
    }
    console.log('Email sent: ' + info.response);
    res.status(200).send('User registered successfully. Please check your email for verification.');
  });
});

// Route for user login
app.post('/login', (req, res) => {
  const { email, password } = req.body;

  // Check if the user exists and the password matches
  if (!users.has(email) || users.get(email).password !== password) {
    return res.status(401).send('Invalid credentials');
  }

  // Generate a 2FA code (replace with actual 2FA implementation)
  const twoFactorCode = Math.floor(1000 + Math.random() * 9000);
  res.status(200).json({ twoFactorCode });
});

// Route for verifying 2FA code
app.post('/verify-2fa', (req, res) => {
  const { email, twoFactorCode } = req.body;

  // For demonstration purposes, accept any 4-digit code as valid
  if (twoFactorCode !== 1234) {
    return res.status(401).send('Invalid 2FA code');
  }

  // Log the user's visit time (replace with database logic)
  const visitTime = new Date().toLocaleString();
  if (!users.has(email)) {
    users.set(email, { visits: [] });
  }
  users.get(email).visits.push(visitTime);

  res.status(200).json({ message: 'Login successful', visitTime });
});

// Route for fetching user location
app.post('/get-location', (req, res) => {
  const { latitude, longitude } = req.body;
  res.status(200).json({ latitude, longitude });
});

// Route for fetching weather information based on user location
app.post('/get-weather', async (req, res) => {
  const { latitude, longitude } = req.body;

  // Replace 'your-openweathermap-api-key' with your actual OpenWeatherMap API key
  const openWeatherMapApiKey = 'your-openweathermap-api-key';
  const apiUrl = `http://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&appid=${openWeatherMapApiKey}&units=metric`;

  try {
    const response = await fetch(apiUrl);
    const data = await response.json();

    res.status(200).json({ weather: data.weather[0].description, temperature: data.main.temp });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).send('Internal Server Error');
  }
});

// Start the server and listen on the specified port
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
