const mysql = require("mysql");
const jwt =require("jsonwebtoken");
const bcrypt=require("bcryptjs");
const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+])[A-Za-z\d!@#$%^&*()_+]{8,}$/;
exports.signup =(req,res)=>{
    console.log("formdata:",req.body);
    const { signupFirstName, signupLastName, signupSex, signupDOB, signupAddress, signupEmail, signupPassword,confirmPassword } = req.body;
    console.log(signupFirstName, signupLastName, signupSex, signupDOB, signupAddress, signupEmail, signupPassword,confirmPassword);

    const db= mysql.createConnection({
        host:process.env.DATABASE_HOST,
        user:process.env.DATABASE_USER,
        password:process.env.DATABASE_PASSWORD,
        database:process.env.DATABASE
    });
    db.query('SELECT email FROM users WHERE email=?', [signupEmail], async(error,results)=>{
        if(error){
            console.log(error);
        }
        if(results.length>0){
            return res.render("signup",{
                message:"Email is already registered"
            });

        }else if(!passwordRegex.test(signupPassword)){
            return res.render("signup",{
                message:"Please use strong password"
            });
        }
        else if(signupPassword!==confirmPassword){
            return res.render("signup",{
                message:"Passwords do not match"
            });
        }
        let hashedPassword = await bcrypt.hash(signupPassword,8);
        console.log(hashedPassword);
        db.query("Insert INTO users SET ?",{
            first_name:signupFirstName,
            last_name:signupLastName,
            last_name:signupSex,
            date_of_birth:signupDOB,
            address:signupAddress,
            email:signupEmail,
            password:hashedPassword},
            (error,results)=>{
                if(error){
                    console.log(error);
                }
                else{
                    console.log(results);
                    return res.render("signup",{
                        message:"User Registered Successfully"
                    });
                }
            }
        );
        
    });
    
}
exports.login =(req,res)=>{
    const {loginUsername,loginPassword} = req.body;
    console.log(loginUsername,loginPassword);
    const db= mysql.createConnection({
        host:process.env.DATABASE_HOST,
        user:process.env.DATABASE_USER,
        password:process.env.DATABASE_PASSWORD,
        database:process.env.DATABASE
    });
    if(!loginUsername || loginPassword){
        return res.render("login",{
            message:"Please provide an Email and Password"
        });
    }
    else{
        db.query('SELECT email,password FROM users WHERE email=?', [loginUsername], async(error,results)=>{
            if(error){
                console.log(error);
            }

            if(results.length==0){
                return res.render("login",{
                    message:"Email is not registered"
                });
            }
            bcrypt.compare(loginPassword, results[0].password, (err, result) => {
                if (err) {
                console.error(err);
                }
            
                if (result) {
                    return res.render("dashboard");

                } else {
                    return res.render("login",{
                        message:"Password is Incorrect"
                    });
                }
            });
        });
    }

}
exports.logout=(req,res)=>{
    return res.render('index');
};